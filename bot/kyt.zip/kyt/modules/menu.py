from reseller import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a:
		msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**⟨ ADMIN PANEL MENU ⟩**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
** Hallo** __{sender.first_name}__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🔰 👥Total Member/reseller:** `{member}`
**🤖 Bot Uptime:** `{get_uptime()}`
"""
		z = await event.edit(msg,buttons=[
[Button.inline(" Panel Create Account ","submenu1")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
		if not z:
			await event.respond(msg,buttons=[
[Button.inline(" Panel Create Account ","submenu1")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")
		else:
			msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
       ** 🔰 MEMBER PANEL 🔰**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🔰 👤 Member Information :**
**🔰 💌 Email :** `{sender.username}@sfvt.net`
**🔰 🆔 Member Id :** `{sender.id}`
**🔰 💵 Saldo :** RP.`{val["saldo"]}`
**🔰 📍 Role :** `{val["level"]}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🔰 🤖 Bot Uptime:** `{get_uptime()}`
**🔰 👥 Total Member/reseller:** `{member}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🔰 🤖** @abecasdee13
"""
			x = await event.edit(msg, buttons=[
[Button.inline(" SSH OVPN MANAGER ","ssh"),
Button.inline(" VMESS MANAGER ","vmess")],
[Button.inline(" VLESS MANAGER ","vless"),
Button.inline(" TROJAN MANAGER ","trojan")],
[Button.inline(" 🔰 TAMBAH SALDO 🔰 ","info")]]) 
			if not x:
				await event.respond(msg, buttons=[
[Button.inline(" SSH OVPN MANAGER ","ssh"),
Button.inline(" VMESS MANAGER ","vmess")],
[Button.inline(" VLESS MANAGER ","vless"),
Button.inline(" TROJAN MANAGER ","trojan")],
[Button.inline(" 🔰 TAMBAH SALDO 🔰 ","info")]])
