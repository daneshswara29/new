from reseller import *

@bot.on(events.CallbackQuery(data=b'register'))
async def regis(event):
    inline = [
[Button.inline(" RESELLER ","reseller"),
Button.inline(" USER ","user")],
[Button.inline(" Back To Menu","menu")]]
    await event.edit("Pilih Role Nya",buttons=inline)
    
@bot.on(events.CallbackQuery(data=b'reseller'))
async def reseller(event):
    db = get_db()
    x = db.execute("SELECT * FROM admin").fetchall()
    a = [v[0] for v in x]
    sender = await event.get_sender()
    if sender.id in a:
        async with bot.conversation(event.chat_id) as conv:
            await event.edit("**User ID: **")
            id_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            id = id_event.message.message

            # Check if the user ID already exists in the user table
            existing_user = db.execute("SELECT member FROM user WHERE member = ?", (id,)).fetchone()
            if existing_user:
                await event.respond("User ID sudah terdaftar. Silakan gunakan ID lain.", buttons=[[Button.inline("BACK TO MENU", "menu")]])
                return

            await event.respond("**Saldo: **")
            saldo_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            saldo = saldo_event.message.message

            await event.respond("**Email: **")
            email_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            email = email_event.message.message

            # Insert new user data into the user table
            db.execute("INSERT INTO user (member, saldo, email, level) VALUES (?, ?, ?, ?)",
                       (id, saldo, email, "reseller"))
            db.commit()
            await event.respond(f"""
**━━━━━━━━━━━━━━━━**
**⟨ Registrasi Sukses ⟩**
**━━━━━━━━━━━━━━━━**
**» User ID:** `{id}`
**» Saldo:** `{saldo}`
**» Email reseller:** `{email}`
**━━━━━━━━━━━━━━━━**
""", buttons=[[Button.inline("BACK TO MENU", "menu")]])

@bot.on(events.CallbackQuery(data=b'user'))
async def user(event):
    db = get_db()
    x = db.execute("SELECT * FROM admin").fetchall()
    a = [v[0] for v in x]
    sender = await event.get_sender()
    if sender.id in a:
        async with bot.conversation(event.chat_id) as conv:
            await event.edit("**User ID: **")
            id_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_id = id_event.message.message

            # Cek apakah User ID sudah ada di tabel user
            existing_user = db.execute("SELECT * FROM user WHERE member = ?", (user_id,)).fetchone()
            if existing_user:
                await event.respond("User ID sudah terdaftar. Silakan gunakan ID lain atau hubungi admin.", buttons=[[Button.inline("BACK TO MENU", "menu")]])
                return

            await event.respond("**Saldo: **")
            saldo_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            saldo = saldo_event.message.message

            await event.respond("**Email:**")
            email_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            email = email_event.message.message

            # Masukkan data user baru ke dalam tabel user
            db.execute("INSERT INTO user (member, saldo, email, level) VALUES (?, ?, ?, ?)",
                       (user_id, saldo, email, "user"))
            db.commit()
            await event.respond(f"""
**━━━━━━━━━━━━━━━━**
**⟨ Registrasi Sukses ⟩**
**━━━━━━━━━━━━━━━━**
**» User ID:** `{user_id}`
**» Saldo:** `{saldo}`
**» Email User:** `{email}`
**━━━━━━━━━━━━━━━━**
""", buttons=[[Button.inline("BACK TO MENU", "menu")]])