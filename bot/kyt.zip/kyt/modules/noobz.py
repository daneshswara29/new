from reseller import *
		
@bot.on(events.CallbackQuery(data=b'noobzvpn-trial'))
async def trial(event):
		async def trial_(event):
			z = db.execute("SELECT buttonname FROM noobzvpn").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				harga = db.execute("SELECT harga FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				domain = db.execute("SELECT domain FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				limitip = db.execute("SELECT limitip FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f"/trial-noobz"
				trial = requests.get("http://"+domain+":6969/trial-noobzvpn").text.split(":")
				exp = 1
				today = DT.date.today()
				later = today + DT.timedelta(days=int(exp))
				print(trial)
				msg = f"""

**◇━━━━━━━━━━━━━◇**
**⟨  noobzvpn Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**◇━━━━━━━━━━━━━◇**
**» Host              :** `{domain}`
**» Port STB         :** `2082`
**» Port TCP         :** `8443`
**◇━━━━━━━━━━━━━◇**
**🗓 Expired Until:** `{later}`
"""

				await event.respond(msg)
				dat = {"email":val["email"],
                                "protocol":"noobzvpn-trial",
                                "server":domain,
                                "exp":str(later)}
				await notifstrr(dat,event)

		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-noobzvpn'))
async def noobzvpn(event):
	async def noobzvpn_(event):
		z = db.execute("SELECT buttonname FROM noobzvpn").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga = db.execute("SELECT harga FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		limitip = db.execute("SELECT limitip FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim); print(limitip)
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
** ⟨ INFORMASI SERVER NOOBZVPN ⟩ **
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Max Login:** `{limitip}` Device
**🔰 Harga 30 Day:** `{harga}`
**🔰 Total Akun Dibuat:** `{cont}/{lim}`
**━━━━━━━━━━━━━━━━━━━━━━━**
** Pilih Ya Untuk Lanjut...!! **

"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.edit("**Dibatalkan.**",buttons=[[Button.inline("Back To Menu","menu")]])
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as pw:
					await event.respond("**Password: **")
					pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					pw = await pw
					pw = pw.message.message.replace(" ","")
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < harga:
				await event.respond("**Saldo Anda Tidak cukup**",buttons=[[Button.inline(" BACK TO MENU","menu")]])
			else:
				if exp == "30":
					min = harga

				param = f"/addnoobz/exp?user={user}&password={pw}&exp={exp}&limitip=2"
				r = requests.get("http://"+domain+":6969"+param).text
				if r == "success":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM noobzvpn WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE noobzvpn SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except Exception as e:
						print(str(e))
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					msg = f"""

**◇━━━━━━━━━━━━━◇**
**⟨  noobzvpn Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**◇━━━━━━━━━━━━━◇**
**» Host              :** `{domain}`
**» Port STB         :** `2082`
**» Port TCP         :** `8443`
**◇━━━━━━━━━━━━━◇**
**🗓 Expired Until:** `{later}`
"""
				
					await event.respond(msg)
					dat = {
				"email":val["email"],
                                "protocol":"noobzvpn",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
					await event.respond("Pembelian Sukses!",buttons=[[Button.inline("Back To Menu","menu")]])

				else:
					await event.respond("""
__**ERROR**__

**PROBABLY :-** `Username Already Exist`, `Server Error`
""",buttons=[[Button.inline(" BACK TO MENU","menu")]])
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await noobzvpn_(event)
	else:
		await noobzvpn_(event)
		
@bot.on(events.CallbackQuery(data=b'noobz'))
async def smenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namanoobz()
	har = harganoobz()
	serv = []
	for x, y in zip(ser, har):
		print(x, y, a)
		serv.append(f"**🔰 {x}  30 Day** `Rp.{y}`\n")
	if val == "true":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**             🔰 Info Harga 🔰**
**━━━━━━━━━━━━━━━━━━━━━━━**

{"".join(serv)}
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[
[Button.inline(" CREATED NOOBZVPN ","create-noobzvpn"),
Button.inline(" CREATED TRIAL NOOBZVPN ","noobzvpn-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Protokol Kosong")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**             🔰 Info Harga 🔰**
**━━━━━━━━━━━━━━━━━━━━━━━**

{"".join(serv)}
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg, buttons=[
[Button.inline(" CREATED NOOBZVPN ","create-noobzvpn"),
Button.inline(" CREATED TRIAL NOOBZVPN ","noobzvpn-trial")],

[Button.inline("🔙 Back To Menu",f"menu")]])