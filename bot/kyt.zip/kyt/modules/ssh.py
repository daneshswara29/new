from reseller import *
		
@bot.on(events.CallbackQuery(data=b'renssh'))
async def renssh(event):
		async def renssh_(event, level):
			z = db.execute("SELECT buttonname FROM ssh").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			do.append([Button.inline("🔙 Back To Menu","menu")])
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("utf-8")
					harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					if level == 'reseller':
					    harga = max(0, harga - 2000) # Diskon 2000 untuk reseller, contoh
					domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
					r = requests.get("http://"+domain+":2605/ceksh").text
					all_ = r.split("\n")
					all_list = []
					for x in all_:
						all_list.append("`"+x+"`")
						y = "\n".join(all_list)
						msg = f"""
**◇━━━━━━━━━━━━━━━━━━◇**
**   CEK USER SSH FROM SERVER   **
**◇━━━━━━━━━━━━━━━━━━◇**
** Nama Server:** `{buttonname}`
** Domain:** `{domain}`
** Isp:** `{z["isp"]}`
** Country:** `{z["country"]}`
** Region:** `{z["region"]}`
** City:** `{z["city"]}`
**◇━━━━━━━━━━━━━━━━━━◇**
{y}
**Choose User Number**
"""
					await event.edit(msg)
			async with bot.conversation(event.chat_id) as num:
					num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					num = await num
					num = num.message.message
			async with bot.conversation(event.chat_id) as user:
					await event.reply("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if int(val["saldo"]) < harga:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "30":
					min = harga
				param = f":2605/rensh?num={num}&exp={exp}&limitip={limitip}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE ssh SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					print(r)
					msg = f"""
**◇━━━━━━━━━━━━━━━━━━◇**
** Successfully Renewed **
**◇━━━━━━━━━━━━━━━━━━◇**
**» Renew:** `SSH`
**» Client Name:** `{user}`
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━━◇**

"""
					await event.respond(msg)
					dat = {
				"email":val["email"],
                                "protocol":"Renew SSH",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
					await event.respond("Pembelian Sukses!",buttons=[[Button.inline("Back To Menu","menu")]])
		sender = await event.get_sender()
		sender_id = sender.id
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		data = event.data.decode("ascii").split("-")[0]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				val = {"saldo":"100000000"}
				await renssh_(event)
		else:
			level = get_level(sender_id)  # Mendapatkan level user dari database
			await renssh_(event, level)
			
@bot.on(events.CallbackQuery(data=b'ssh-trial'))
async def trial(event):
		async def trial_(event):
			z = db.execute("SELECT buttonname FROM ssh").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			do.append([Button.inline("🔙 Back To Menu","menu")])
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				portwsntls = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				#nsdomain = db.execute("SELECT ns FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				pubkey = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				#link = db.execute("SELECT link FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				#portwstls = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				#portdb = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f"/trial-ssh"
				trial = requests.get("http://"+domain+":2605/trial-ssh").text.split(":")
				exp = 1
				today = DT.date.today()
				later = today + DT.timedelta(days=int(exp))
				print(trial)
				msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ TRIAL SSH OVPN Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Username         :** `{trial[0].strip()}`
**» Password         :** `{trial[1]}`**◇━━━━━━━━━━━━━◇**
**» Host             :** `{domain}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port UdpSSH      :** `1-65535`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080, 8081-9999`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `443`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**» Pub Key          :** `{pubkey}`
**◇━━━━━━━━━━━━━◇**
**» Payload WSS      :** 
```GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Upgrade: websocket[crlf][crlf]```
** Payload WSS HTTPS :**
```GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**◇━━━━━━━━━━━━━◇**
**» SSH WS PORT 80**
`{domain}:80@{trial[0].strip()}:{trial[1]}`**◇━━━━━━━━━━━━━◇**
**» Link OpenVPN     :** `https://{domain}:89`
**◇━━━━━━━━━━━━━◇**
**» Save Link Account:** `https://{domain}:89/ssh-{trial[0].strip()}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓 Expired Until:** `60 Menit`
"""

				message = await event.respond(msg)
				await bot.pin_message(event.chat_id, message, notify=True)
				await event.respond("Trial Akun SSH Sukses",buttons=[[Button.inline("Back To Menu","menu")]])
				dat = {"email":val["email"],
                                "protocol":"SSH-trial",
                                "server":domain,
                                "exp":str(later)}
				await notifstrr(dat,event)

		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await event.edit("**Saldo Kamu Kosong**", buttons=[[Button.inline("Back To Menu", b"menu")]])
		else:
			await trial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def ssh(event):
    async def ssh_(event, level):
        z = db.execute("SELECT buttonname FROM ssh").fetchall()
        do = []
        for i,k in zip(z[0::2], z[1::2]):
            print(i)
            print(k)
            do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
        if ( len(z) % 2 ) == True:
            do.append([Button.inline(z[-1][0])])
        do.append([Button.inline("🔙 Back To Menu","menu")])
        await event.edit(
buttons=do)

        async with bot.conversation(event.chat_id) as conv:
            conv = conv.wait_event(events.CallbackQuery)
            buttonname = await conv
            buttonname = buttonname.data.decode("utf-8")

        harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        if level == 'reseller':
            harga = max(0, harga - 2000) # Diskon 2000 untuk reseller, contoh
        domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        lim = db.execute("SELECT limcounted FROM ssh WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        cont = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()

        msg = f"""
**◇◇━━━━━━━━━━━━━━━━━━━━━◇**
** ⟨ INFORMASI SERVER SSH ⟩ **
**◇◇━━━━━━━━━━━━━━━━━━━━━◇**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Max Login:** `{limitip}` Device
**🔰 Harga 30 Day:** `{harga}`
**🔰 Total Akun Dibuat:** `{cont}/{lim}`
**◇◇━━━━━━━━━━━━━━━━━━━━━◇**
** Pilih Ya Untuk Lanjut...!! **
"""
        await event.edit(msg, buttons=[
            [Button.inline(" Ya ", "y"), Button.inline(" Tidak ", "n")],
            [Button.inline(" 🔙 ", "menu")]
        ])
        
        async with bot.conversation(event.chat_id) as con:
            con = con.wait_event(events.CallbackQuery)
            con = await con
        
        if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
            await event.edit("**Dibatalkan.**", buttons=[[Button.inline(" BACK TO MENU", "menu")]])
        elif con.data.decode("ascii") == "y":
            async with bot.conversation(event.chat_id) as user:
                await event.edit("**Username: **")
                user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = await user
                user = user.message.message
            
            async with bot.conversation(event.chat_id) as pw:
                await event.respond("**Password: **")
                pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = await pw
                pw = pw.message.message.replace(" ", "")
            
            async with bot.conversation(event.chat_id) as exp:
                await event.respond("**Choose Expiry day**", buttons=[
                    [Button.inline("30 Day", "30")]
                ])
                exp = exp.wait_event(events.CallbackQuery)
                exp = await exp
                exp = exp.data.decode("ascii")
            
            if lim == cont:
                await event.respond("**Server Full**")
            elif int(val["saldo"]) < harga:
                await event.respond("**Saldo Anda Tidak cukup**", buttons=[[Button.inline(" BACK TO MENU", "menu")]])
            else:
                if exp == "30":
                    min = harga
                
                param = f"/adduser/exp?user={user}&password={pw}&exp={exp}&limitip={limitip}"
                r = requests.get(f"http://{domain}:2605{param}").text
                if r == "success":
                    try:
                        db.execute("UPDATE user SET saldo = ? WHERE member = ?", (int(val["saldo"]) - int(min), sender.id,))
                        count = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
                        db.execute("UPDATE ssh SET counted = (?) WHERE domain = (?)", (int(count) + int(1), domain,))
                        db.commit()
                    except Exception as e:
                        print(str(e))
                        pass
                    today = DT.date.today()
                    later = today + DT.timedelta(days=int(exp))
                    msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨  SSH OVPN Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**◇━━━━━━━━━━━━━◇**
**» Host             :** `{domain}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port UdpSSH      :** `1-65535`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080, 8081-9999`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `443`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**◇━━━━━━━━━━━━━◇**
**» Payload WSS      :** 
```GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Upgrade: websocket[crlf][crlf]```
** Payload WSS HTTPS :**
```GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**◇━━━━━━━━━━━━━◇**
**» SSH WS UDP**
`{domain}:1-65535@{user.strip()}:{pw.strip()}`
**◇━━━━━━━━━━━━━◇**
**» SSH WS PORT 80**
`{domain}:80@{user.strip()}:{pw.strip()}`
**◇━━━━━━━━━━━━━◇**
**» Link OpenVPN     :** `http://{domain}:89/udp.ovpn`
**◇━━━━━━━━━━━━━◇**
**» Save Link Account:** `http://{domain}:89/ssh-{user}.txt`
**◇━━━━━━━━━━━━━◇**
**🗓 Expired Until:** `{later}`
"""
                    message = await event.respond(msg)
                    await bot.pin_message(event.chat_id, message, notify=True)
                    dat = {
                        "email": val["email"],
                        "protocol": "SSH",
                        "server": domain,
                        "exp": str(later)}
                    await notifs(dat, event)
                    await event.respond("Pembelian Sukses!", buttons=[[Button.inline("Back To Menu", "menu")]])

                else:
                    await event.respond("""
__**ERROR**__

**PROBABLY :-** `Username Already Exist`, `Server Error`
""", buttons=[[Button.inline(" BACK TO MENU", "menu")]])

    sender = await event.get_sender()
    sender_id = sender.id
    val = valid(sender.id)
    db = get_db()
    x = db.execute("SELECT * FROM admin").fetchall()
    a = [v[0] for v in x]
    data = event.data.decode("ascii").split("-")[0]
    
    if val == "false":
        if sender.id not in a:
            await event.answer("Akses Ditolak")
        else:
            val = {"saldo": "100000000"}
            await ssh_(event, 'admin')
    else:
        level = get_level(sender_id)  # Mendapatkan level user dari database
        await ssh_(event, level)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def smenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namash()
	har = hargash()
	serv = []
	for x, y in zip(ser, har):
		print(x, y)
		serv.append(f"**🔰 {x}  30 Day** `Rp.{y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
SSH/OpenVPN Menu
- SSH
- SSH SSL
- SSH WS
- SSH UDP
- SSH WS-SSL
- OpenVPN
- SlowDNS
- BadVPN UDPgw

Rules:
- Max 2 Login
- Max 2x Peringatan (Ganti Password)
- Peringatan 3x Banned

Info Harga :
** **
{"".join(serv)}
"""
			await event.edit(msg, buttons=[
[Button.inline(" CREATED SSH ","create-ssh"),
Button.inline(" CREATED TRIAL SSH ","ssh-trial")],
[Button.inline(" RENEW SSH ","renssh")],
[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("❌")
	else:
		msg = f"""
SSH/OpenVPN Menu
- SSH
- SSH SSL
- SSH WS
- SSH UDP
- SSH WS-SSL
- OpenVPN
- SlowDNS
- BadVPN UDPgw

Rules:
- Max 2 Login
- Max 2x Peringatan (Ganti Password)
- Peringatan 3x Banned

Info Harga :
** **
{"".join(serv)}
"""
		await event.edit(msg, buttons=[
[Button.inline(" CREATED SSH ","create-ssh"),
Button.inline(" CREATED TRIAL SSH ","ssh-trial")],
[Button.inline(" RENEW SSH ","renssh")],
[Button.inline("🔙 Back To Menu",f"menu")]])