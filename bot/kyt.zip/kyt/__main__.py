from reseller import *
from importlib import import_module
from reseller.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("reseller.modules." + module_name)
bot.loop.run_until_complete(sbot())

aapp.run()

